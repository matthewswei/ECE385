#include "text_mode_vga_color.h"
#include "palette_test.h"

int main() {
	//textVGATest();
	paletteTest();
	textVGAColorScreenSaver();
	return 0;
}
